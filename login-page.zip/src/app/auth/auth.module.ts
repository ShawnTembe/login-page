import { AuthEffects } from './state/auth.effects';
import { EffectsModule } from '@ngrx/effects';
import { LoginComponent } from './login/login.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: '', redirectTo: 'login' },
      { path: 'login', component: LoginComponent },
    ],
  },
];

@NgModule({
    declarations: [LoginComponent],
    imports: [ 
      CommonModule, 
      ReactiveFormsModule,
      EffectsModule.forFeature(),
      RouterModule.forChild(routes)],
  })

  export class AuthModule {}